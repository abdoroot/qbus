<?php

return array (
  'fields' => 
  array (
    'admin_notes' => 'fields.admin_notes',
    'code' => 'code',
    'date_from' => 'fields.date_from',
    'date_to' => 'date_to',
    'discount' => 'discount',
    'name' => 'name',
    'singular' => 'code',
    'status' => 'status',
    'type' => 'type',
  ),
  'plural' => 'coupons',
  'singular' => 'coupon',
  'status' => 
  array (
    'approved' => 'approved',
    'pending' => '.pending',
    'rejected' => 'rejected',
  ),
  'types' => 
  array (
    'amount' => 'amount',
    'percentage' => 'percentage',
  ),
);
