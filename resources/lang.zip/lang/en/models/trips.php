<?php

return array (
  'datetime' => 'datetime',
  'features' => 'features',
  'fields' => 
  array (
    'additional' => 'additional',
    'auto_approve' => 'auto approve',
    'bus_id' => 'bus id',
    'date_from' => 'date from',
    'date_to' => 'date to',
    'description' => 'description',
    'destination' => 'destination',
    'destination_id' => 'destination id',
    'fees' => 'fees',
  ),
  'plural' => 'trips',
  'singular' => 'trip',
  'types' => 
  array (
    'multi' => 'Multiple trips',
    'one-way' => 'one way',
    'round' => 'Round Trip',
  ),
);
