<?php

return array (
  'fields' => 
  array (
    'seat_num' => 'seat number',
  ),
  'plural' => 'tickets',
  'singular' => 'ticket',
);
