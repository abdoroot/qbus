<?php

return array (
  'fields' => 
  array (
    'arrival_terminal_id' => 'arrival_terminal_id',
    'bus_fees' => 'bus_fees',
    'from_city_id' => 'from_city_id',
    'name' => 'destination',
    'starting_terminal_id' => 'starting_terminal_id',
    'stops' => 'stops',
    'to_city_id' => '.to_city_id',
  ),
  'plural' => 'destinations',
  'singular' => 'destinantion',
);
