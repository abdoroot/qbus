<?php

return array (
  'fields' => 
  array (
    'count' => 'count',
    'package_id' => 'package id',
    'status' => 'status',
    'total' => 'total',
    'user_id' => 'user id',
  ),
  'plural' => 'packages orders',
);
