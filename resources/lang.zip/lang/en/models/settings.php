<?php

return array (
  'plural' => 'Settings',
  'singular' => 'Settings',
);
