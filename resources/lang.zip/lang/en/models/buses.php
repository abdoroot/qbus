<?php

return array (
  'fields' => 
  array (
    'account_id' => 'account id',
    'active' => 'active',
    'image' => 'image',
    'passengers' => 'passengers',
    'plate' => 'plate',
  ),
  'inactive' => 'inactive',
  'plural' => 'buses',
  'singular' => 'bus',
);
