<?php

return array (
  'fields' => 
  array (
    'count' => 'count',
    'provider_notes' => 'provider notes',
    'status' => 'status',
    'total' => 'total',
    'trip_id' => 'trip id',
    'type' => 'type',
    'user_id' => 'user id',
    'user_notes' => 'user notes',
  ),
  'plural' => 'trip orders',
  'singular' => 'trip order',
  'status' => 
  array (
    'approved' => 'approved',
    'pending' => 'pending',
    'rejected' => 'rejected',
  ),
  'types' => 
  array (
    'multi' => 'Multiple trips',
    'one_way' => 'one way',
    'round' => 'round',
  ),
);
