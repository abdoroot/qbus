<?php

return array (
  'fields' => 
  array (
    'additional' => 'additional',
    'auto_approve' => 'auto_approve',
    'bus_fees' => 'bus_fees',
    'date_from' => 'date_from',
    'description' => '.description',
    'fees' => 'fees',
    'image' => 'image',
    'name' => 'name',
    'starting_city_id' => 'tarting_city_id',
    'time_from' => '.time_from',
  ),
  'plural' => 'Packages',
  'singular' => 'Package',
);
