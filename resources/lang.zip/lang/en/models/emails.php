<?php

return array (
  'fields' => 
  array (
    'email' => 'email',
  ),
  'plural' => 'emails',
  'singular' => 'email',
);
