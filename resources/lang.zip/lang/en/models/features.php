<?php

return array (
  'fields' => 
  array (
    'icon' => 'icon',
    'text' => 'text',
    'title' => 'title',
  ),
  'plural' => 'features',
  'singular' => 'feature',
);
