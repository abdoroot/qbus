<?php

return array (
  'fields' => 
  array (
    'bus_id' => 'bus id',
    'created_at' => 'created at',
    'date_from' => 'date from',
    'date_to' => 'date to',
    'fees' => 'fees',
    'provider_notes' => 'provider notes',
    'status' => 'status',
    'tax' => 'tax',
    'time' => 'time',
    'time_from' => 'time from',
    'time_to' => 'time to',
    'total' => 'total',
    'user_id' => 'user id',
    'user_notes' => 'user notes',
  ),
  'plural' => 'Buses order',
  'singular' => 'Bus order',
  'status' => 
  array (
    'approved' => 'approved',
    'pending' => 'pending',
    'rejected' => 'rejected',
  ),
  'time' => 'time',
);
