<?php

return array (
  'active' => 'active',
  'fields' => 
  array (
    'active' => 'active',
    'email' => 'email',
    'password' => 'password',
    'phone' => 'phone',
    'role' => 'role',
    'username' => 'username',
  ),
  'inactive' => 'inactive',
  'plural' => 'accounts',
  'roles' => 
  array (
    'admin' => 'admin',
    'driver' => 'driver',
  ),
  'singular' => 'account',
);
