<?php

return array (
  'singular' => 'BusOrderDatetime',
  'plural' => 'BusOrderDatetimes',
  'fields' => 
    array (
      'id' => 'Id',
      'bus_order_id' => 'Bus Order Id',
      'bus_id' => 'Bus Id',
      'date' => 'Date',
      'time_from' => 'Time from',
      'time_to' => 'Time to',
      'created_at' => 'Created At',
      'updated_at' => 'Updated At',
    )
);
