<?php

return array (
  'approved' => 'Approved',
  'fields' => 
  array (
    'address' => 'address',
    'approve' => 'Approve',
    'block' => 'Block',
    'block_notes' => 'Block notes',
    'comm_name' => 'name',
    'comm_reg_img' => 'image',
    'comm_reg_num' => 'number',
    'email' => 'Email',
    'image' => 'Image',
    'name' => 'Name',
    'notes' => 'Notes',
    'password' => 'Password',
    'phone' => 'Phone',
    'tax' => 'tax',
    'tax_cert_num' => 'tax certificate number',
  ),
  'plural' => 'Providers',
  'singular' => 'Provider',
  'unapproved' => 'Unapproved',
);
