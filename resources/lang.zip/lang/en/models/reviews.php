<?php

return array (
  'bus_order_id' => 'bus order id',
  'fields' => 
  array (
    'bus_order_id' => 'bus order id',
    'name' => 'name',
    'package_id' => 'package id',
    'publish' => 'publish',
    'rate' => 'rate',
    'trip_id' => 'trip id',
  ),
  'plural' => 'review',
  'singular' => 'review',
);
