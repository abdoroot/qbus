<?php

return array (
  'fields' => 
  array (
    'address' => 'address',
    'block' => 'Block',
    'block_notes' => 'Block notes',
    'date_of_birth' => 'date of birth',
    'email' => 'Email',
    'image' => 'Image',
    'marital_status' => 'marital status',
    'name' => 'Name',
    'notes' => 'Notes',
    'password' => 'Password',
    'phone' => 'Phone',
    'wallet' => 'wallet',
  ),
  'plural' => 'Users',
  'singular' => 'User',
);
