<?php

return array (
  'fields' => 
  array (
    'image' => 'image',
    'text' => 'text',
    'title' => 'title',
  ),
  'plural' => 'services',
  'singular' => 'service',
);
