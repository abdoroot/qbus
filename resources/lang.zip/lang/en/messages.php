<?php

return array (
  'deleted' => ':model deleted successfully.',
  'not_found' => ':model not found',
  'retrieved' => ':model retrieved successfully.',
  'saved' => ':model saved successfully.',
  'updated' => ':model updated successfully.',
);
