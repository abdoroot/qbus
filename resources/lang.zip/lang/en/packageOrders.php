<?php

return array (
  'plural' => 'packages orders',
);
