<?php

return array (
  'about' => 'کے بارے میں',
);
