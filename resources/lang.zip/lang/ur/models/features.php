<?php

return array (
  'singular' => 'Feature',
  'plural' => 'Features',
  'fields' => 
  array (
    'id' => 'Id',
    'title' => 'Title',
    'text' => 'Text',
    'icon' => 'Icon',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
