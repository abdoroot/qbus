<?php

return array (
  'singular' => 'Service',
  'plural' => 'Services',
  'fields' => 
  array (
    'id' => 'Id',
    'title' => 'Title',
    'text' => 'Description',
    'image' => 'Image',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
