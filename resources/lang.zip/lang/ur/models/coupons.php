<?php

return array (
  'singular' => 'Coupon',
  'plural' => 'Coupons',
  'fields' => 
  array (
    'id' => 'Id',
    'provider_id' => 'Provider Id',
    'name' => 'Name',
    'date_from' => 'Date From',
    'date_to' => 'Date To',
    'type' => 'Type',
    'discount' => 'Discount',
    'code' => 'Code',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
