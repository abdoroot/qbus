<?php

return array (
  'singular' => 'Package',
  'plural' => 'Packages',
  'fields' => 
  array (
    'id' => 'Id',
    'provider_id' => 'Provider Id',
    'name' => 'Name',
    'bus_fees' => 'Bus Fees',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
  'packageCities' => [
    'title' => 'Destination Cities',
    'subtitle' => 'Path cities in order which are included in the package',
  ]
);
