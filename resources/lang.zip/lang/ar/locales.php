<?php

return array (
  'ar' => 'العربية',
  'en' => 'English',
);
