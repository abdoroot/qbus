<?php

return array (
  'fields' => 
  array (
    'address' => 'العنوان',
    'block' => 'محظور',
    'block_notes' => 'رسائل الحظر',
    'date_of_birth' => 'تاريخ الميلاد',
    'email' => 'بريد الالكتروني',
    'image' => 'صورة',
    'marital_status' => 'الحالة الاجتماعية',
    'name' => 'اسم',
    'notes' => 'ملاحظات',
    'password' => 'كلمة السر',
    'phone' => 'رقم الهاتف',
    'wallet' => 'المحفظة',
  ),
  'plural' => 'مستخدمين',
  'singular' => 'مستخدم',
);
