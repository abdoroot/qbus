<?php

return array (
  'plural' => 'الاعدادات',
  'singular' => 'الاعدادات',
);
