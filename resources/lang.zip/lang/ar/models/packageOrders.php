<?php

return array (
  'fields' => 
  array (
    'count' => 'العدد',
    'package_id' => 'معرف البرنامج',
    'status' => 'الحالة',
    'total' => 'الاجمالي',
    'user_id' => 'معرف المستخدم',
  ),
  'plural' => 'طلبات البرامج',
);
