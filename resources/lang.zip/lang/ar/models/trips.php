<?php

return array (
  'datetime' => 'الوقت والتاريخ',
  'features' => 'المميزات',
  'fields' => 
  array (
    'additional' => 'الاضافات',
    'auto_approve' => 'الموافقة التلقائية',
    'bus_id' => 'معرف الباص',
    'date_from' => 'التاريخ من',
    'date_to' => 'التاريخ الي',
    'description' => 'الوصف',
    'destination' => 'الوجهات',
    'destination_id' => 'الوجهة',
    'fees' => 'الرسوم',
    'provider_notes' => 'ملاحظات شركة النقل',
    'time_from' => 'الوقت من',
    'time_to' => 'الوقت الي',
    'type' => 'النوع',
  ),
  'plural' => 'الرحلات',
  'singular' => 'الرحلة',
  'types' => 
  array (
    'multi' => 'رحلات متعددة',
    'one-way' => 'اتجاه واحد',
    'round' => 'ذهاب وعودة',
  ),
);
