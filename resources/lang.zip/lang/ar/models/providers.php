<?php

return array (
  'approved' => 'موافق عليه',
  'fields' => 
  array (
    'address' => 'العنوان',
    'approve' => 'موافقة',
    'block' => 'محظور',
    'block_notes' => 'رسائل الحظر',
    'comm_name' => 'الاسم',
    'comm_reg_img' => 'الصورة',
    'comm_reg_num' => 'الرقم',
    'email' => 'البريد الالكتروني',
    'image' => 'صورة',
    'name' => 'الاسم',
    'notes' => 'ملاحظات',
    'password' => 'كلمة السر',
    'phone' => 'رقم الهاتف',
    'tax' => 'ضريبة',
    'tax_cert_num' => 'رقم الشهادة الضريبية',
  ),
  'plural' => 'شركات النقل',
  'singular' => 'شركة النقل',
  'unapproved' => 'غير موافق عليه',
);
