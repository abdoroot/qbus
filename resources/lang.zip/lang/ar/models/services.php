<?php

return array (
  'fields' => 
  array (
    'image' => 'صورة',
    'text' => 'نص',
    'title' => 'عنوان',
  ),
  'plural' => 'الخدمات',
  'singular' => 'خدمة',
);
