<?php

return array (
  'fields' => 
  array (
    'email' => 'بريد الكتروني',
  ),
  'plural' => 'بريد الكتروني',
  'singular' => 'بريد الكتروني',
);
