<?php

return array (
  'bus_order_id' => 'معرف طلب الباص',
  'fields' => 
  array (
    'bus_order_id' => 'معرف طلب الباص',
    'name' => 'الاسم',
    'package_id' => 'معرف البرنامج',
    'publish' => 'نشر',
    'rate' => 'التقييم',
    'trip_id' => 'معرف الوجهة',
  ),
  'plural' => 'التقيمات',
  'singular' => 'التقييم',
);
