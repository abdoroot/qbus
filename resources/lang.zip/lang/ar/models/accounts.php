<?php

return array (
  'active' => 'نشط',
  'fields' => 
  array (
    'active' => 'نشط',
    'email' => 'البريد الالكتروني',
    'password' => 'كلمة المرور',
    'phone' => 'رقم الهاتف',
    'role' => 'وظيفة',
    'username' => 'اسم المستخدم',
  ),
  'inactive' => 'غير نشط',
  'plural' => 'الحسابات',
  'roles' => 
  array (
    'admin' => 'ادمن',
    'driver' => 'سائق',
  ),
  'singular' => 'الحساب',
);
