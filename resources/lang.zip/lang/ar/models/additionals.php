<?php

return array (
  'fields' => 
  array (
    'icon' => 'ايقونة',
    'name' => 'الاسم',
  ),
  'plural' => 'الاضافات',
  'singular' => 'الاضافة',
);
