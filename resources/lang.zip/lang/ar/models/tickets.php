<?php

return array (
  'fields' => 
  array (
    'seat_num' => 'رقم المقعد',
  ),
  'plural' => 'التذاكر',
  'singular' => 'التذكرة',
);
