<?php

return array (
  'fields' => 
  array (
    'count' => 'العدد',
    'provider_notes' => 'ملاحظات شركة النقل',
    'status' => 'الحالة',
    'total' => 'الاجمالي',
    'trip_id' => 'معرف الرحلة',
    'type' => 'نوع الرحلة',
    'user_id' => 'معرف المستخدم',
    'user_notes' => 'ملاحظات المستخدم',
  ),
  'plural' => 'طلبات الرحلات',
  'singular' => 'طلبات الرحلات',
  'status' => 
  array (
    'approved' => 'موافق',
    'pending' => 'ريثما',
    'rejected' => 'مرفوض',
  ),
  'types' => 
  array (
    'multi' => 'رحلات متعددة',
    'one_way' => 'اتجاه واحد',
    'round' => 'ذهاب وعودة',
  ),
);
