<?php

return array (
  'fields' => 
  array (
    'additional' => 'إضافي',
    'auto_approve' => 'الموافقة التلقائية',
    'bus_fees' => 'رسوم الحافلات',
    'date_from' => '.التاريخ من',
    'description' => 'وصف',
    'fees' => 'رسوم',
    'image' => 'الصورة',
    'name' => 'اسم',
    'starting_city_id' => 'بدء معرف المدينة',
    'time_from' => 'الوقت من',
  ),
  'plural' => 'البرامج',
  'singular' => 'البرنامج',
);
