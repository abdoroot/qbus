<?php

return array (
  'fields' => 
  array (
    'arrival_terminal_id' => 'وصول معرف المحطة',
    'bus_fees' => 'رسوم الحافلات',
    'from_city_id' => 'من معرف المدينة',
    'name' => 'الوجهة',
    'starting_terminal_id' => 'بدء معرف المحطة',
    'stops' => 'توقف',
    'to_city_id' => 'إلى معرف المدينة',
  ),
  'plural' => 'الوجهات',
  'singular' => 'وجهة',
);
