<?php

return array (
  'active' => 'نشط',
  'fields' => 
  array (
    'account_id' => 'معرف الحساب',
    'active' => 'نشط',
    'image' => 'صورة',
    'passengers' => 'الركاب',
    'plate' => 'اللوحة',
  ),
  'inactive' => 'غير نشط',
  'plural' => 'الباصات',
  'singular' => 'الباص',
);
