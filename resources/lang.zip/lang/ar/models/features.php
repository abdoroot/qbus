<?php

return array (
  'fields' => 
  array (
    'icon' => 'أيقونة',
    'text' => 'نص',
    'title' => 'لقب',
  ),
  'plural' => 'ميزات',
  'singular' => 'ميزة',
);
