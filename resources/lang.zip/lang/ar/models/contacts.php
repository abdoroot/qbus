<?php

return array (
  'fields' => 
  array (
    'email' => 'البريد الإلكتروني',
    'message' => 'الرسائل',
    'name' => 'الاسم',
    'read_at' => 'قرأ في',
    'reply_message' => 'رسالة الرد',
    'subject' => 'الموضوع',
    'type' => 'النوع',
  ),
  'plural' => 'رسائل الاتصال',
  'replied' => 'أجاب',
  'singular' => 'رسالة الاتصال',
  'types' => 
  array (
    'complaint' => 'شكوى',
    'contact' => 'اتصل',
    'enquiry' => 'تحقيق',
    'help' => 'مساعدة',
    'suggestion' => 'اقتراح',
  ),
  'unread' => 'غير مقروء',
  'unreplied' => 'لم يتم الرد عليه',
);
