<?php

return array (
  'fields' => 
  array (
    'active' => 'نشط',
    'email' => 'البريد الالكتروني',
    'name' => 'الاسم',
    'password' => 'كلمة المرور',
    'status' => 'الحالة',
  ),
  'plural' => 'جمع',
  'singular' => 'مفرد',
);
