<?php

return array (
  'fields' => 
  array (
    'bus_id' => 'معرف الباص',
    'created_at' => 'أنشئت في',
    'date_from' => 'التاريخ من',
    'date_to' => 'التاريخ إلى',
    'fees' => 'الرسوم',
    'provider_notes' => 'ملاحظة شركة النقل',
    'status' => 'الحالة',
    'tax' => 'الضريبة',
    'time' => 'الوقت',
    'time_from' => 'الوقت من',
    'time_to' => 'الوقت الي',
    'total' => 'الاجمالي',
    'user_id' => 'معرف المستخدم',
    'user_notes' => 'ملاحظات المستخدم',
  ),
  'plural' => 'طلبات الباصات',
  'singular' => 'طلب باص',
  'status' => 
  array (
    'approved' => 'وافق',
    'pending' => 'ريثما',
    'rejected' => 'مرفوض',
  ),
  'time' => 'الوقت',
);
