<?php

return array (
  'fields' => 
  array (
    'admin_notes' => 'ملاحظات المشرف',
    'code' => 'رمز التخفيض',
    'date_from' => 'من تاريخ',
    'date_to' => 'التاريخ إلى',
    'discount' => 'تخفيض',
    'name' => 'الاسم',
    'singular' => 'رمز الخصم',
    'status' => 'الحالة',
    'type' => 'يكتب',
  ),
  'plural' => 'الكوبونات',
  'singular' => 'رمز التخفيض',
  'status' => 
  array (
    'approved' => 'وافق',
    'pending' => 'حتى',
    'rejected' => '.مرفوض',
  ),
  'types' => 
  array (
    'amount' => 'مقدار',
    'percentage' => 'النسبة المئوية',
  ),
);
