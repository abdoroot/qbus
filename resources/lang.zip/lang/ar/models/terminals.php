<?php

return array (
  'fields' => 
  array (
    'name' => 'الاسم',
  ),
  'plural' => 'المحطات',
  'singular' => 'المحطة',
);
