<?php

return array (
  'plural' => 'طلبات البرامج',
);
