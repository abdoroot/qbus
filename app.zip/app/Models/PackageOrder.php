<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class PackageOrder
 * @package App\Models
 * @version April 13, 2022, 4:53 am UTC
 *
 * @property \App\Models\Package $package
 * @property \App\Models\User $user
 * @property integer $package_id
 * @property integer $user_id
 * @property integer $provider_id
 * @property integer $count
 * @property number $total
 * @property string $status
 * @property string $user_notes
 * @property string $provider_notes
 * @property boolean $user_archive
 * @property boolean $provider_archive
 */
class PackageOrder extends Model
{
    use HasFactory;

    public $table = 'package_orders';

    public $fillable = [
        'package_id',
        'user_id',
        'provider_id',
        'count',
        'total',
        'status',
        'user_notes',
        'provider_notes',
        'user_archive',
        'provider_archive',
        'fees',
        'tax',
        'coupon_id',
        'admin_notes',
        'additional'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'package_id' => 'integer',
        'user_id' => 'integer',
        'provider_id' => 'integer',
        'count' => 'integer',
        'total' => 'float',
        'status' => 'string',
        'user_notes' => 'string',
        'provider_notes' => 'string',
        'user_archive' => 'boolean',
        'provider_archive' => 'boolean',
        'fees' => 'double',
        'tax' => 'double',
        'coupon_id' => 'integer',
        'admin_notes' => 'string',
        'additional' => 'array'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'package_id' => 'required|exists:packages,id',
        'count' => 'required|integer',
        'user_notes' => 'nullable|string',
        'code' => 'nullable|exists:coupons,code',
    ];

    /**
     * Validation rules from provider side.
     *
     * @var array
     */
    public static $provider_rules = [
        'package_id' => 'required|exists:packages,id',
        'user_id' => 'required|exists:users,id',
        'count' => 'required|integer',
        'user_notes' => 'nullable|string',
        'coupon_id' => 'nullable|exists:coupons,id',
    ];

    /**
     * Validation update rules
     *
     * @var array
     */
    public static $update_rules = [
        'status' => 'nullable|in:pending,approved,rejected',
        'provider_notes' => 'nullable|string|required_if:status,rejected',
    ];
    
    /**
     * Validation admin rules
     *
     * @var array
     */
    public static $admin_rules = [
        'admin_notes' => 'required|string',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function package()
    {
        return $this->belongsTo(\App\Models\Package::class, 'package_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function provider()
    {
        return $this->belongsTo(\App\Models\Provider::class, 'provider_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function coupon()
    {
        return $this->belongsTo(\App\Models\Coupon::class, 'coupon_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     **/
    public function tickets()
    {
        return $this->hasMany(\App\Models\Ticket::class, 'package_order_id');
    }

    public function getStatusColorAttribute()
    {
        switch ($this->status) {
            case 'pending':
                return 'warning';
                break;

            case 'canceled':
                return 'default';
                break;

            case 'approved':
                return 'info';
                break;
            
            case 'rejected':
                return 'danger';
                break;

            case 'paid':
                return 'primary';
                break;

            case 'complete':
                return 'success';
                break;

            default:
                return 'secondary';
                break;
        }
    }

    public function getStatusSpanAttribute()
    {
        $color = $this->status_color;
        $color = ($color == 'default' ? 'inverse' : $color);
        return "<span class='label label-{$color}'>{$this->status}</span>";
    }

    public function getDiscountAttribute()
    {
        if(is_null($coupon = $this->coupon)) return null;
        $subtotal = $this->fees + $this->tax;
        if($coupon->type == 'discount') return $coupon->discount;
        return $subtotal * $coupon->discount / 100;
    }

    public function getAdditionalFeesAttribute()
    {
        if(is_null($this->additional)) return null;

        $fees = 0;
        foreach($this->additional as $additional) {
            $fees += $additional['fees'];
        }
        return $fees;
    }

    public function additionals()
    {
        $additionals = [];
        foreach($this->additional ?? [] as $value) {
            $additional = \App\Models\Additional::find($value['id']);
            if(!is_null($additional)) {
                $additionals[] = [
                    'id' => $additional->id,
                    'additional' => $additional,
                    'fees' => $value['fees'],
                    'count' => isset($value['count']) ? $value['count'] : 1
                ];
            }
        }

        return $additionals;
    }
}
