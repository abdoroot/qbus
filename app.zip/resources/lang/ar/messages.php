<?php

return array (
  'deleted' => 'حذف',
  'not_found' => 'غير موجود',
  'retrieved' => 'استرجاع',
  'saved' => 'حفظ',
  'updated' => 'محدث',
);
