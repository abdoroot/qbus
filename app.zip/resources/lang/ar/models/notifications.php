<?php

return array (
  'fields' => 
  array (
    'admin_id' => 'معرف الادمن',
    'icon' => 'أيقونة',
    'provider_id' => 'معرف المزود',
    'text' => 'نص',
    'title' => 'العنوان',
    'to' => 'الي',
    'type' => 'نوع',
    'url' => 'رابط',
    'user_id' => 'معرف المستخدم',
  ),
  'plural' => 'اشعارات',
  'singular' => 'اشعار',
  'to' => 
  array (
    'all_admins' => 'جميع الادمنز',
    'all_providers' => 'جميع المزودين',
    'all_users' => 'جميع المستخدمين',
  ),
  'types' => 
  array (
    'danger' => 'danger',
    'info' => 'info',
    'primary' => 'primary',
    'success' => 'success',
    'warning' => 'warning',
  ),
);
