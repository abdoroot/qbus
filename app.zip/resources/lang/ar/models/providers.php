<?php

return array (
  'approved' => 'موافق عليه',
  'fields' => 
  array (
    'approve' => 'موافقة',
    'block' => 'محظور',
    'block_notes' => 'رسائل الحظر',
    'email' => 'البريد الالكتروني',
    'image' => 'صورة',
    'name' => 'الاسم',
    'notes' => 'ملاحظات',
    'password' => 'كلمة السر',
    'phone' => 'رقم الهاتف',
  ),
  'plural' => 'شركات النقل',
  'singular' => 'شركة النقل',
  'unapproved' => 'غير موافق عليه',
);
