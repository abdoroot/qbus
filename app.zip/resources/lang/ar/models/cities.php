<?php

return array (
  'fields' => 
  array (
    'name' => 'الاسم',
  ),
  'plural' => 'المدن',
  'singular' => 'المدينة',
);
