<?php

return array (
  'fields' => 
  array (
    'block' => 'محظور',
    'block_notes' => 'رسائل الحظر',
    'email' => 'بريد الالكتروني',
    'image' => 'صورة',
    'name' => 'اسم',
    'notes' => 'ملاحظات',
    'password' => 'كلمة السر',
    'phone' => 'رقم الهاتف',
  ),
  'plural' => 'مستخدمين',
  'singular' => 'مستخدم',
);
