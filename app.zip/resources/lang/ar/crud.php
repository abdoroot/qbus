<?php

return array (
  'action' => 'حدث',
  'add_new' => 'اضف جديد',
  'are_you_sure' => 'هل أنت واثق؟',
  'back' => 'رجوع',
  'cancel' => 'الغاء',
  'create' => 'انشاء',
  'created_at' => 'أنشئت في',
  'deleted_at' => 'محذوف في',
  'detail' => 'التفاصيل',
  'edit' => 'تعديل',
  'id' => 'معرف',
  'reply' => 'رد',
  'save' => 'حفظ',
  'show' => 'عرض',
  'updated_at' => 'تم التحديث في',
);
