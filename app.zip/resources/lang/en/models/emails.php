<?php

return array (
  'singular' => 'Email',
  'plural' => 'Emails',
  'fields' => 
  array (
    'id' => 'Id',
    'email' => 'Email',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
