<?php

return array (
  'singular' => 'Destination',
  'plural' => 'Destinations',
  'fields' => 
  array (
    'id' => 'Id',
    'provider_id' => 'Provider Id',
    'from_city_id' => 'From City Id',
    'to_city_id' => 'To City Id',
    'bus_fees' => 'Bus Fees',
    'passenger_fees' => 'Passenger Fees',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
