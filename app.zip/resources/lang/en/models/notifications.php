<?php

return array (
  'fields' => 
  array (
    'admin_id' => 'Admin id',
    'icon' => 'Icon',
    'provider_id' => 'Provider id',
    'text' => 'Text',
    'title' => 'Title',
    'to' => 'To',
    'type' => 'Type',
    'url' => 'Url',
    'user_id' => 'User id',
  ),
  'plural' => 'Notifications',
  'singular' => 'Notification',
  'to' => 
  array (
    'all_admins' => 'All admins',
    'all_providers' => 'All providers',
    'all_users' => 'All users',
  ),
  'types' => 
  array (
    'danger' => 'Danger',
    'info' => 'Info',
    'primary' => 'Primary',
    'success' => 'Success',
    'warning' => 'Warning',
  ),
);
