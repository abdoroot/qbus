<?php

return array (
  'approved' => 'Approved',
  'fields' => 
  array (
    'approve' => 'Approve',
    'block' => 'Block',
    'block_notes' => 'Block notes',
    'email' => 'Email',
    'image' => 'Image',
    'name' => 'Name',
    'notes' => 'Notes',
    'password' => 'Password',
    'phone' => 'Phone',
  ),
  'plural' => 'Providers',
  'singular' => 'Provider',
  'unapproved' => 'Unapproved',
);
