<?php

return array (
  'singular' => 'Bus',
  'plural' => 'Buses',
  'fields' => 
  array (
    'id' => 'Id',
    'plate' => 'Plate Number',
    'image' => 'Image',
    'passengers' => 'Passengers Number',
    'provider_id' => 'Company',
    'account_id' => 'Driver',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
