<?php

return array (
  'fields' => 
  array (
    'email' => 'Email',
    'message' => 'Message',
    'name' => 'Name',
    'read_at' => 'Read at',
    'reply_message' => 'Reply message',
    'subject' => 'Subject',
    'type' => 'Type',
  ),
  'plural' => 'Contact messages',
  'singular' => 'Contact message',
  'types' => 
  array (
    'complaint' => 'Complaint',
    'contact' => 'Contact',
    'enquiry' => 'Enquiry',
    'help' => 'Help',
    'suggestion' => 'Suggestion',
  ),
);
