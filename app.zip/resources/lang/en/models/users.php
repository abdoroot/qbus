<?php

return array (
  'fields' => 
  array (
    'block' => 'Block',
    'block_notes' => 'Block notes',
    'email' => 'Email',
    'image' => 'Image',
    'name' => 'Name',
    'notes' => 'Notes',
    'password' => 'Password',
    'phone' => 'Phone',
  ),
  'plural' => 'Users',
  'singular' => 'User',
);
