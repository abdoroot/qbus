<?php

return array (
  'singular' => 'Additional',
  'plural' => 'Additionals',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'icon' => 'Icon',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
