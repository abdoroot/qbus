<?php

return array (
  'fields' => 
  array (
    'active' => 'Active',
    'email' => 'Email',
    'name' => 'Name',
    'password' => 'Password',
    'status' => 'Status',
  ),
  'plural' => 'Admins',
  'singular' => 'Admin',
);
