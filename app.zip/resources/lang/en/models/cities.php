<?php

return array (
  'fields' => 
  array (
    'name' => 'Name',
  ),
  'plural' => 'Cities',
  'singular' => 'City',
);
