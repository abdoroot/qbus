<?php

return array (
  'singular' => 'Terminal',
  'plural' => 'Terminals',
  'fields' => 
  array (
    'id' => 'Id',
    'provider_id' => 'Provider Id',
    'name' => 'Name',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
