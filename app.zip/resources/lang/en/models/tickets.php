<?php

return array (
  'singular' => 'Ticket',
  'plural' => 'Tickets',
  'fields' => 
  array (
    'id' => 'Id',
    'trip_order_id' => 'Trip Order',
    'seat_num' => 'Seat No.',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
