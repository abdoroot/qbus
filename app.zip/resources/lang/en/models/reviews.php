<?php

return array (
  'singular' => 'Review',
  'plural' => 'Reviews',
  'fields' => 
  array (
    'id' => 'Id',
    'trip_id' => 'Trip',
    'user_id' => 'User',
    'bus_order_id' => 'Bus Order',
    'provider_id' => 'Provider',
    'name' => 'Name',
    'email' => 'Email',
    'rate' => 'Rate',
    'review' => 'Review',
    'publish' => 'Publish',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At'
  ),
);
