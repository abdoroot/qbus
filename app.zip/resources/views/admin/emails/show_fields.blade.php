<!-- Email Field -->
<tr>
    <th>@lang('models/emails.fields.email')</th>
    <td>{{ $email->email }}</td>
</tr>

<!-- Created At Field -->
<tr>
    <th>@lang('models/emails.fields.created_at')</th>
    <td>{{ $email->created_at }}</td>
</tr>

<!-- Updated At Field -->
<tr>
    <th>@lang('models/emails.fields.updated_at')</th>
    <td>{{ $email->updated_at }}</td>
</tr>

